package com.sona.vikashmurali.addcustomer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Search extends AppCompatActivity {
    EditText id;
    Button search;
    String data="",id_str;
    String URL ="http://192.168.1.102:8080/bank/retrive.php?";
    String job_str,marital_str,education_str,defaultt_str,housign_str,loan_str,contact_str,month_str,poutcome_str;
    int day_flot,duration_flot,pdays_flot,campaign_flot,previous_flot,age_double,balance_double;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        id=(EditText)findViewById(R.id.id);
        search=(Button)findViewById(R.id.search);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchondb();
            }

            private void searchondb() {
                System.out.println("url is  "+URL);
                System.out.println("id is  "+id.getText().toString());
               data+="cid="+id.getText().toString();//change id to int
                URL+=data;
                System.out.println("url is  "+URL);
                JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL,

                        new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                System.out.println("inside on response"+URL);
                                JSON_PARSE_DATA_AFTER_WEBCALL(response);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                System.out.println("inside on error"+error.toString());
                            }
                        });

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

                requestQueue.add(jsonArrayRequest);
            }

            public void JSON_PARSE_DATA_AFTER_WEBCALL(JSONArray array){
                System.out.println("inside on parse json");
                for(int i = 0; i<array.length(); i++) {

                    JSONObject json = null;
                    try {
                         json = array.getJSONObject(i);

                        age_double=json.getInt("age");
                        job_str=json.getString("job");
                        marital_str=json.getString("marital");
                        education_str=json.getString("education");
                        defaultt_str=json.getString("_default");
                        balance_double=json.getInt("balance");
                        housign_str=json.getString("housing");
                        loan_str=json.getString("loan");
                        contact_str=json.getString("contact");
                        day_flot= json.getInt("day");
                        month_str=json.getString("month");
                        duration_flot=json.getInt("duration");
                        campaign_flot=json.getInt("campaign");
                        pdays_flot=json.getInt("pdays");
                        previous_flot=json.getInt("previous");
                        poutcome_str=json.getString("poutcome");

                        System.out.println("parsing  json data"+job_str);

                    } catch (JSONException e) {

                        e.printStackTrace();
                    }

                }

                showresult();
            }
        });
    }

    private void showresult() {
        Intent intent = new Intent(getApplicationContext(),Show_result.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.putExtra("age",age_double);
        intent.putExtra("job",job_str);
        intent.putExtra("marital",marital_str);
        intent.putExtra("education",education_str);
        intent.putExtra("defaultt",defaultt_str);
        intent.putExtra("balance",balance_double);
        intent.putExtra("housing",housign_str);
        intent.putExtra("loan",loan_str);
        intent.putExtra("contact",contact_str);
        intent.putExtra("day",day_flot);
        intent.putExtra("month",month_str);
        intent.putExtra("duration",duration_flot);
        intent.putExtra("campaign",campaign_flot);
        intent.putExtra("pdays",pdays_flot);
        intent.putExtra("previous",previous_flot);
        intent.putExtra("poutcome",poutcome_str);
        startActivity(intent);
        finish();

    }


}
