package com.sona.vikashmurali.addcustomer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

public class analysis extends AppCompatActivity {
    Spinner deposit_spinner;
    //Button click;
    TextView result_print;
    String deposit_str;
    String URL="http://192.168.1.102:8080/bank/selection.php?";//ipaddress to be changed
    String result_to_print="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis);

       deposit_spinner =(Spinner)findViewById(R.id.spinner);
       result_print =(TextView)findViewById(R.id.tv);
        //click=(Button)findViewById(R.id.click);
        deposit_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                result_to_print="Customer ID's";
                deposit_str=deposit_spinner.getSelectedItem().toString();
                fetch_selected_deposits();//if it is not run create button and call this method
                URL="http://192.168.1.102:8080/bank/selection.php?";
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                URL="http://192.168.1.102:8080/bank/selection.php?";
            }
        });
        URL="http://192.168.1.102:8080/bank/selection.php?";
    }
    private void fetch_selected_deposits() {
        String data="deposit="+deposit_str;
        URL+=data;
        System.out.println(URL);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL,

                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        JSON_PARSE_DATA_AFTER_WEBCALL(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("----------------inside on error"+error.toString());
                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }

    public void JSON_PARSE_DATA_AFTER_WEBCALL(JSONArray array){
        for(int i = 0; i<array.length(); i++) {

            JSONObject json = null;
            try {
                json = array.getJSONObject(i);
                int j=i+1;
                result_to_print+="\n "+j+". CID"+json.getInt("cid");
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        result_print.setText(result_to_print+"\n\n");

    }
}
