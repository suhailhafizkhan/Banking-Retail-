package com.sona.vikashmurali.addcustomer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class second_page extends AppCompatActivity  {

    //String URL =" http://localhost:8080/bank/insert.php?age=20&job=admin&marital=single&education=primary&_default=no&balance=1600&housing=yes&loan=no&contact=cellular&day=10&month=june&duration=5600&campaign=8&pdays=-1&previous=0&poutcome=unknown&deposit=yes";
    String URL ="http://192.168.1.102:8080/bank/insert.php?";
    int cid;
    String data="";
    String job_str,marital_str,education_str,defaultt_str,housign_str,loan_str,contact_str,age_str="",balance_str="";
    EditText day,duration,campaign,pdays,previous;
    Button submit;
    String month_str="",poutcome_str="";
    Spinner month_spinner,poutcome_spinner;
    String day_str="",duration_str="",camp_str="",pday_str="",prev_str="";
    int day_int,duration_int,pdays_int,campaign_int,previous_int,age_int,balance_int;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);

        submit=(Button)findViewById(R.id.submit);

        month_spinner=(Spinner)findViewById(R.id.month);
        poutcome_spinner=(Spinner)findViewById(R.id.poutcome);

        day=(EditText)findViewById(R.id.day);
        duration=(EditText)findViewById(R.id.duration);
        campaign=(EditText)findViewById(R.id.campaign);
        pdays=(EditText)findViewById(R.id.pdays);
        previous=(EditText)findViewById(R.id.previous);


System.out.println("before intent"+day_str+duration_str+camp_str+pday_str+prev_str);
        //get the value from first page - main activity
        Intent intent=getIntent();
        job_str=intent.getStringExtra("job");
        marital_str=intent.getStringExtra("marital");
        education_str=intent.getStringExtra("education");
        defaultt_str=intent.getStringExtra("defaultt");
        housign_str=intent.getStringExtra("housing");
        loan_str=intent.getStringExtra("loan");
        contact_str=intent.getStringExtra("contact");
        age_str=intent.getStringExtra("age");
        balance_str=intent.getStringExtra("balance");

        System.out.println("after intent"+day_str+duration_str+camp_str+pday_str+prev_str);

        //int values
        try {
            age_int = Integer.parseInt(age_str);
            balance_int = Integer.parseInt(balance_str);

        }
        catch (Exception e){
            System.out.println(e.toString());
            Toast.makeText(getApplicationContext(),"give correct numbers",Toast.LENGTH_SHORT).show();

        }

        /*day_flot= Integer.parseInt(day.getText().toString());
        duration_flot= Integer.parseInt(duration.getText().toString());
        pdays_flot= Integer.parseInt(pdays.getText().toString());
        campaign_flot=Integer.parseInt(campaign.getText().toString());
        previous_flot=Integer.parseInt(previous.getText().toString());
*/


        month_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                month_str=month_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        poutcome_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                poutcome_str=poutcome_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        System.out.println("after spinner"+day_str+duration_str+camp_str+pday_str+prev_str);

        //submit - send to remote database
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("calling sent to db"+day_str+duration_str+camp_str+pday_str+prev_str);

                day_str=day.getText().toString();
                System.out.println("after getting day"+day_str);

                duration_str=duration.getText().toString();
                camp_str=campaign.getText().toString();
                pday_str=pdays.getText().toString();
                prev_str=previous.getText().toString();

                day_int = Integer.parseInt(day_str);
                duration_int = Integer.parseInt(duration_str);
                campaign_int = Integer.parseInt(camp_str);
                pdays_int = Integer.parseInt(pday_str);
                previous_int = Integer.parseInt(prev_str);
                showresult();
            }
        });
    }




    private void showresult() {


        Intent intent = new Intent(getApplicationContext(),Show_result.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.putExtra("age",age_int);
        intent.putExtra("job",job_str);
        intent.putExtra("marital",marital_str);
        intent.putExtra("education",education_str);
        intent.putExtra("defaultt",defaultt_str);
        intent.putExtra("balance",balance_int);
        intent.putExtra("housing",housign_str);
        intent.putExtra("loan",loan_str);
        intent.putExtra("contact",contact_str);
        intent.putExtra("day",day_int);
        intent.putExtra("month",month_str);
        intent.putExtra("duration",duration_int);
        intent.putExtra("campaign",campaign_int);
        intent.putExtra("pdays",pdays_int);
        intent.putExtra("previous",previous_int);
        intent.putExtra("poutcome",poutcome_str);
        startActivity(intent);
        finish();

    }

}
